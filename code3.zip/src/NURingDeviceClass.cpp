#include "NURingDeviceClass.h"

NURingDeviceClass::NURingDeviceClass() { 

}