/**
 * @file SerialOutputClass.h
 * @author Tomasz Trzpit
 * @brief Handle serial output
 * @version 0.1
 * @date 2025-10-03
 * 
 */

#pragma once

// Pre-built libraries
#include <Arduino.h>	// For arduino functions

// Libraries for other classes passed by reference
#include "Amplifier.h"
#include "ArmEncoders.h"
#include "Gamepad.h"
#include "TaskManager.h"


/*  ==========================================================
 *  ==========================================================
 * 
 *   SSSS   TTTTTT  RRRRR    U     U   CCCCC    TTTTTT   SSSS
 *  SS        TT    RR  RR   U     U   CC         TT    SS
 *  SS        TT    RR  RR   U     U   CC         TT    SS
 *   SSSS     TT    RRRRR    U     U   CC         TT     SSSS
 *      SS    TT    RR  RR   U     U   CC         TT        SS
 *      SS    TT    RR  RR   U     U   CC         TT        SS
 *   SSSS     TT    RR   RR   UUUUU    CCCCC      TT     SSSS
 * 
 *  ==========================================================
 *  ==========================================================
 */



// Forward declarations
class AmplifierClass;	   // Amplifier
class ArmEncoderClass;	   // Arm encoders
class GamepadClass;		   // Gamepad input
class TaskManagerClass;	   // Task manager


// System state
enum class systemStateEnum : uint8_t { IDLE, MEASURING_RANGE_OF_MOTION, DISCRIMINATION_TASK_TESTING };	// Enum of states


class SoftwareSerialInterfaceClass {

	/************************
	*  Serial Constructors  *
	*************************/
	public:
	SoftwareSerialInterfaceClass( systemStateEnum& systemStateRef, AmplifierClass& ampRef, ArmEncoderClass& armEncRef, GamepadClass& gamepadRef, TaskManagerClass& taskManagerRef );	// Default constructor
	static SoftwareSerialInterfaceClass* instance;																																		// Singleton-style hook for global ISR shim

	private:
	systemStateEnum&  SystemStateReference;
	AmplifierClass&	  AmplifierReference;	   // Reference to amplifier
	ArmEncoderClass&  ArmEncoderReference;	   // Reference to arm encoder
	GamepadClass&	  GamepadReference;		   // Reference to game pad
	TaskManagerClass& TaskManagerReference;	   // Reference to task manager
	



	/*******************
	*  Initialization  *
	********************/
	public:
	void Begin();	 // Initialize class


	/**************
	*  Accessors  *
	***************/
	public:
	void GetKeyboardInput();

	/**************************
	*  Keyboard Serial Input  *
	***************************/
	private:
	void RespondToKeyboardCommands();					   // Main function to parse commands into responses
	void Respond_SetTensionValue();						   // Set tension
	void Respond_ToggleTensionState();					   // Set tension
	void Respond_PrintSystemStateBlock();				   // Print system state
	void Respond_ToggleScrollingState();				   // Toggle system state scroll
	void Respond_ZeroPlatformEncoders();				   // Zero platform encoders
	void Respond_ZeroMotorEncoders();					   // Zero motor encoders
	void Respond_ToggleAmplifierOutput();				   // Toggle system output
	void Respond_ToggleCurrentLimits();					   // Toggle current limiter
	void Respond_MeasureAmplifierRangeOfMotionLimits();	   // Toggle ROM measurement
	void Respond_TestRangeOfMotionLimits();				   // Toggle ROM measurement
	void Respond_DisciminationTaskCardinal();			   // Start discrimination test

	String incomingSerialString = "";	 // Serial string being received

	public:
	void OnSoftwareSerialEvent();	 // Instance handler for software serial

	/******************
	*  Serial Output  *
	*******************/
	public:
	void PrintMenu();						  // Draw on-screen menu
	void PrintSystemState();				  // Prints the system state once
	void PrintScrollingOutput();			  // Prints a scrolling system state line
	bool isScrollingOutputEnabled = false;	  // Flag for scrolling output


	/************
	*  Gamepad  *
	*************/
	private:
	void ParseGamepadInput();	 // Process gamepad inputs

	public:
	bool   isGamepadButtonPressed = false;	   // Flag if button press is waiting
	int8_t gamepadButton		  = -1;		   // Gamepad button
	String gamepadString		  = "None";	   // Gamepad button name


	/****************
	*  SystemState  *
	*****************/
	


	/*********************
	*  Display Elements  *
	**********************/
	private:
	void ShowElement_PlatformEncoders();	  // Show the platform encoder values
	void ShowElement_MotorEncoderCounts();	  // Show motor encoder values
	void ShowElement_MotorEncoderAngles();	  // Show motor encoder values
	void ShowElement_BaudRate();			  // Show encoder baud rat


	/***************
	 *  Accessors  *
	 ***************/
	public:
	// Gamepad
	void UpdateButtonState( bool newState, int8_t newButton, String newName );	  // Updates the button press
};